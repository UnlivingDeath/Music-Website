
const UserModel = require('./userModel')

module.exports = {
    UserModel
}