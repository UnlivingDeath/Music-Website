
const UserController = require('./userController')
const IndexController = require('./indexController')


module.exports = {
    IndexController,
    UserController
}