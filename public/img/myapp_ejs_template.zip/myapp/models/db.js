const mongoose = require('mongoose')
// const constant = require('../lib/constant')
// const dbClient =  new MongoClient(`mongodb://${constant.DB_USER}:${constant.DB_PASS}@${constant.DB_HOST}:${constant.DB_PORT}/?authSource=admin`)

module.exports = mongoose
